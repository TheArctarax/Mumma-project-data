Implemented waveform models
==============================

.. automodule:: gwmemory.waveforms.base
    :members:

.. automodule:: gwmemory.waveforms.approximant
    :members:

.. automodule:: gwmemory.waveforms.surrogate
    :members:

.. automodule:: gwmemory.waveforms.nr
    :members:

.. automodule:: gwmemory.waveforms.mwm
    :members:
