#create memory template
#=====================

#Using NR surrogate waveform __reference__ for an edge-on non-spinning,
#    equal-mass, binary at a distance of 400 MPC.

from __future__ import division, print_function
import gwmemory
from matplotlib.pyplot import *
import numpy as np
#np.seterr(divide='ignore',invalid='ignore')

import pylab
#=====================
fig = figure(figsize=(12, 6))

times = np.linspace(-2., 0.02, 20001)

h_mem, times = gwmemory.frequency_domain_memory(model='IMRPhenomPv2', q=1, total_mass=60,distance=400, inc=np.pi/2, phase=0, times=times)

plot(times, h_mem['plus'] * 1e22)

xlabel('$t (s)$')

show()
close()
