Welcome to the documentation for GWMemory!
==============================================

.. automodule:: gwmemory
    :members:

.. toctree::
   :maxdepth: 3
   :caption: Contents:

   waveforms
   angles
   harmonics
   qnms
   utils