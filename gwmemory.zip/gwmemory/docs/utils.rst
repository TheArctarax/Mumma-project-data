Utils.
==============================

.. automodule:: gwmemory.utils
    :members: