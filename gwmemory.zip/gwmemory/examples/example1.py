from __future__ import division, print_function
import gwmemory
from matplotlib.pyplot import *
import numpy as np

fig = figure(figsize=(12, 6))

qs = [1., 2.]
S1s = [[0., 0., 0.], [0.8, 0., 0.]]
S2s = [[0., 0., 0.], [0., 0.8, 0.]]

colours = ['r', 'b', 'g', 'k']

times = np.linspace(-0.08, 0.02, 10001)

labels = ['Equal-mass, non-spinning']

ax = [fig.add_subplot(2, 1, 1), fig.add_subplot(2, 1, 2)]

for ii, q in enumerate(qs):
    for jj, (S1, S2) in  enumerate(zip(S1s, S2s)):

        h_mem, times = gwmemory.time_domain_memory(q=q, spin_1=S1, spin_2=S2, total_mass=60., distance=400.,
                                                   model='NRSur7dq2', inc=np.pi/2., phase=0, times=times)

        ax[0].plot(times, h_mem['plus'] * 1e22, linestyle='-', color=colours[ii + jj * 2])
        ax[1].plot(times, h_mem['cross'] * 1e22, linestyle='-', color=colours[ii + jj * 2])

        h_mem, times = gwmemory.time_domain_memory(q=q, spin_1=S1, spin_2=S2, total_mass=60., distance=400.,
                                                   model='NRSur7dq2', inc=np.pi/2., phase=0, Lmax=2,
                                                   modes=[(2, 2), (2, -2)], times=times)

        ax[0].plot(times, h_mem['plus'] * 1e22, linestyle=':', color=colours[ii + jj * 2])
        ax[1].plot(times, h_mem['cross'] * 1e22, linestyle=':', color=colours[ii + jj * 2])

xlabel('$t (s)$')
ax[0].set_ylabel('$\delta h_{+} \, \left[10^{-22}\\right]$')
ax[1].set_ylabel('$\delta h_{\\times} \, \left[10^{-22}\\right]$')

ax[0].set_xlim(-0.02, 0.02)
ax[1].set_xlim(-0.02, 0.02)

tight_layout()
show()
close()
